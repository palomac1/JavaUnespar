package AtividadeDesign.FactoryMethod;

public interface Notificacao {
    void notificarUsuario();
}
